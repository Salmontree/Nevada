package cc.polyfrost.oneconfig.libs.universal

import cc.polyfrost.oneconfig.libs.universal.wrappers.message.UTextComponent
import net.minecraft.network.play.server.S02PacketChat

//#if MC>=11602
//$$ import cc.polyfrost.oneconfig.libs.universal.wrappers.UPlayer
//#endif

//#if MC>=11901
//#else
//#if MC>=11900
//$$ // FIXME preprocessor bug: remaps alias references in code to remapped type, so we can't keep the alias
//#if FABRIC
//$$ import net.minecraft.network.message.MessageType as MCMessageType
//#else
//$$ import net.minecraft.network.chat.ChatType
//#endif
//$$ import net.minecraft.util.registry.Registry
//$$ import net.minecraft.util.registry.RegistryKey
//$$
//$$ private object MessageType {
//$$     private fun get(key: RegistryKey<MCMessageType>): Int {
//$$         val registry = UMinecraft.getNetHandler()!!.registryManager.get(Registry.MESSAGE_TYPE_KEY)
//$$         return registry.getRawId(registry.get(key))
//$$     }
//$$     val CHAT: Int
//$$         get() = get(MCMessageType.CHAT)
//$$     val GAME_INFO: Int
//$$         get() = get(MCMessageType.GAME_INFO)
//$$ }
//#elseif MC>=11202
//$$ import net.minecraft.util.text.ChatType
//#else
private object ChatType {
    const val CHAT: Byte = 0
    const val GAME_INFO: Byte = 2
}
//#endif
//#endif

object UPacket {
    @JvmStatic
    fun sendChatMessage(message: UTextComponent) {
        UMinecraft.getNetHandler()!!.handleChat(S02PacketChat(
            message,
            //#if MC>=11901
            //$$ false,
            //#else
            ChatType.CHAT,
            //#endif
            //#if MC>=11600 && MC<11900
            //$$ UPlayer.getUUID(),
            //#endif
        ))
    }

    @JvmStatic
    fun sendActionBarMessage(message: UTextComponent) {
        UMinecraft.getNetHandler()!!.handleChat(S02PacketChat(
            message,
            //#if MC>=11901
            //$$ true,
            //#else
            ChatType.GAME_INFO,
            //#endif
            //#if MC>=11600 && MC<11900
            //$$ UPlayer.getUUID(),
            //#endif
        ))
    }
}
