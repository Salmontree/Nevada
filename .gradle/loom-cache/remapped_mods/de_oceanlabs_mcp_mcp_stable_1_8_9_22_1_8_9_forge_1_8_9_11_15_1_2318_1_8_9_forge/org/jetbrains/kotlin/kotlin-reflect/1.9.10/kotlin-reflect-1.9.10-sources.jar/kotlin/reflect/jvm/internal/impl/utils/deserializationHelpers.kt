/*
 * Copyright 2010-2022 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package kotlin.reflect.jvm.internal.impl.utils

import kotlin.reflect.jvm.internal.impl.metadata.jvm.deserialization.JvmMetadataVersion
import kotlin.reflect.jvm.internal.impl.serialization.deserialization.DeserializationConfiguration

fun DeserializationConfiguration.jvmMetadataVersionOrDefault(): JvmMetadataVersion =
    binaryVersion as? JvmMetadataVersion ?: JvmMetadataVersion.INSTANCE
