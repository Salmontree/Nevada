/*
 * Copyright 2010-2018 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package kotlin.reflect.jvm.internal.impl.descriptors;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import kotlin.reflect.jvm.internal.impl.descriptors.annotations.Annotations;
import kotlin.reflect.jvm.internal.impl.name.Name;
import kotlin.reflect.jvm.internal.impl.types.KotlinType;
import kotlin.reflect.jvm.internal.impl.types.TypeSubstitution;
import kotlin.reflect.jvm.internal.impl.types.TypeSubstitutor;

import java.util.Collection;
import java.util.List;

public interface FunctionDescriptor extends CallableMemberDescriptor {
    @Override
    @NotNull
    DeclarationDescriptor getContainingDeclaration();

    @NotNull
    @Override
    FunctionDescriptor getOriginal();

    @Nullable
    @Override
    FunctionDescriptor substitute(@NotNull TypeSubstitutor substitutor);

    /**
     * This method should be used with a great care, because if descriptor is substituted one, calling 'getOverriddenDescriptors'
     * may force lazy computation, that's unnecessary in most cases.
     * So, if 'getOriginal().getOverriddenDescriptors()' is enough for you, please use it instead.
     * @return
     */
    @Override
    @NotNull
    Collection<? extends FunctionDescriptor> getOverriddenDescriptors();

    /**
     * @return descriptor that represents initial signature, e.g in case of result SimpleFunctionDescriptor.createRenamedCopy it returns
     * descriptor before rename
     */
    @Nullable
    FunctionDescriptor getInitialSignatureDescriptor();

    /**
     * @return true if descriptor signature clashed with some other signature and it's supposed to be legal
     * See java.nio.CharBuffer
     */
    boolean isHiddenToOvercomeSignatureClash();

    @NotNull
    @Override
    FunctionDescriptor copy(DeclarationDescriptor newOwner, Modality modality, DescriptorVisibility visibility, Kind kind, boolean copyOverrides);

    boolean isOperator();

    boolean isInfix();

    boolean isInline();

    boolean isTailrec();

    boolean isHiddenForResolutionEverywhereBesideSupercalls();

    boolean isSuspend();

    @NotNull
    @Override
    kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<? extends FunctionDescriptor> newCopyBuilder();

    interface CopyBuilder<D extends FunctionDescriptor> extends CallableMemberDescriptor.CopyBuilder<D> {
        @NotNull
        @Override
        kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> setOwner(@NotNull DeclarationDescriptor owner);

        @NotNull
        @Override
        kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> setModality(@NotNull Modality modality);

        @NotNull
        @Override
        kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> setVisibility(@NotNull DescriptorVisibility visibility);

        @NotNull
        @Override
        kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> setKind(@NotNull Kind kind);

        @NotNull
        @Override
        kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> setCopyOverrides(boolean copyOverrides);

        @Override
        @NotNull
        kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> setName(@NotNull Name name);

        @NotNull
        kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> setValueParameters(@NotNull List<ValueParameterDescriptor> parameters);

        @NotNull
        @Override
        kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> setTypeParameters(@NotNull List<TypeParameterDescriptor> parameters);

        @NotNull
        @Override
        kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> setReturnType(@NotNull KotlinType type);

        @NotNull
        kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> setContextReceiverParameters(@NotNull List<ReceiverParameterDescriptor> contextReceiverParameters);

        @NotNull
        kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> setExtensionReceiverParameter(@Nullable ReceiverParameterDescriptor extensionReceiverParameter);

        @NotNull
        @Override
        kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> setDispatchReceiverParameter(@Nullable ReceiverParameterDescriptor dispatchReceiverParameter);

        @NotNull
        @Override
        kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> setOriginal(@Nullable CallableMemberDescriptor original);

        @NotNull
        kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> setSignatureChange();

        @NotNull
        @Override
        kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> setPreserveSourceElement();

        @NotNull
        kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> setDropOriginalInContainingParts();

        @NotNull
        kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> setHiddenToOvercomeSignatureClash();

        @NotNull
        kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> setHiddenForResolutionEverywhereBesideSupercalls();

        @NotNull
        kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> setAdditionalAnnotations(@NotNull Annotations additionalAnnotations);

        @NotNull
        @Override
        kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> setSubstitution(@NotNull TypeSubstitution substitution);

        @NotNull
        <V> kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor.CopyBuilder<D> putUserData(@NotNull UserDataKey<V> userDataKey, V value);

        @Nullable
        @Override
        D build();
    }
}
